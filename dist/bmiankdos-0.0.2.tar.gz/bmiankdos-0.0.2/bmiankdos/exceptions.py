class InvalidJSONFileInput(Exception):
    """Raise When Invalid Json File """

class UnrealisticValues(Exception):
    """Raise When Invalid value of height or weight given"""